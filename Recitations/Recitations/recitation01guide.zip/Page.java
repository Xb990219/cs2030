class Page {
    private final String content;

    Page(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return content;
    }
}
